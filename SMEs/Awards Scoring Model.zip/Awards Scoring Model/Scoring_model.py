"""
IPMZ Human Capital Excellence Awards - Enhanced Scoring System
With Persistent Storage, Automatic Rankings, and Comprehensive Reports

INSTALLATION:
pip install streamlit pandas numpy pdfplumber plotly openpyxl python-docx

RUN:
streamlit run award_scoring_system.py
"""

import streamlit as st
import pdfplumber
import pandas as pd
import numpy as np
import re
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
import io
import json
from pathlib import Path

# ===================== CONFIGURATION =====================

class ScoringConfig:
    """Centralized scoring configuration with award-specific parameters"""
    
    # Award categories with specific scoring criteria
    AWARD_CATEGORIES = {
        # INDIVIDUAL AWARDS - HC DIRECTOR OF THE YEAR
        'HC Director of the Year - Private Sector': {
            'category_type': 'Individual',
            'parent_award': 'HC Director of the Year',
            'criteria': [
                {'name': 'Bold, visionary, innovative people strategy aligned with business objectives', 'weight': 30},
                {'name': 'Demonstrated business acumen and commercial contribution', 'weight': 20},
                {'name': 'Strong HC policies, high performance, and innovation success', 'weight': 15},
                {'name': 'Developed a business-integrated, evidence-driven HC team', 'weight': 15},
                {'name': 'Innovativeness (new interventions in 2025) and measurable impact', 'weight': 10},
                {'name': 'Created a people-first executive culture', 'weight': 10}
            ]
        },
        'HC Director of the Year - Public Sector': {
            'category_type': 'Individual',
            'parent_award': 'HC Director of the Year',
            'criteria': [
                {'name': 'Bold, visionary, innovative people strategy aligned with business objectives', 'weight': 30},
                {'name': 'Demonstrated business acumen and commercial contribution', 'weight': 20},
                {'name': 'Strong HC policies, high performance, and innovation success', 'weight': 15},
                {'name': 'Developed a business-integrated, evidence-driven HC team', 'weight': 15},
                {'name': 'Innovativeness (new interventions in 2025) and measurable impact', 'weight': 10},
                {'name': 'Created a people-first executive culture', 'weight': 10}
            ]
        },
        'HC Director of the Year - NGO': {
            'category_type': 'Individual',
            'parent_award': 'HC Director of the Year',
            'criteria': [
                {'name': 'Bold, visionary, innovative people strategy aligned with business objectives', 'weight': 30},
                {'name': 'Demonstrated business acumen and commercial contribution', 'weight': 20},
                {'name': 'Strong HC policies, high performance, and innovation success', 'weight': 15},
                {'name': 'Developed a business-integrated, evidence-driven HC team', 'weight': 15},
                {'name': 'Innovativeness (new interventions in 2025) and measurable impact', 'weight': 10},
                {'name': 'Created a people-first executive culture', 'weight': 10}
            ]
        },
        
        # HC MANAGER OF THE YEAR
        'HC Manager of the Year - Private Sector': {
            'category_type': 'Individual',
            'parent_award': 'HC Manager of the Year',
            'criteria': [
                {'name': 'Leadership and vision in people practices', 'weight': 25},
                {'name': 'Organisational impact and accomplishments', 'weight': 25},
                {'name': 'Commitment to the HC profession and community', 'weight': 20},
                {'name': 'Innovativeness and measurable business impact', 'weight': 30}
            ]
        },
        'HC Manager of the Year - Public Sector': {
            'category_type': 'Individual',
            'parent_award': 'HC Manager of the Year',
            'criteria': [
                {'name': 'Leadership and vision in people practices', 'weight': 25},
                {'name': 'Organisational impact and accomplishments', 'weight': 25},
                {'name': 'Commitment to the HC profession and community', 'weight': 20},
                {'name': 'Innovativeness and measurable business impact', 'weight': 30}
            ]
        },
        'HC Manager of the Year - NGO': {
            'category_type': 'Individual',
            'parent_award': 'HC Manager of the Year',
            'criteria': [
                {'name': 'Leadership and vision in people practices', 'weight': 25},
                {'name': 'Organisational impact and accomplishments', 'weight': 25},
                {'name': 'Commitment to the HC profession and community', 'weight': 20},
                {'name': 'Innovativeness and measurable business impact', 'weight': 30}
            ]
        },
        
        # UPCOMING HC PROFESSIONAL
        'Upcoming HC Professional (35 & below) - Private Sector': {
            'category_type': 'Individual',
            'parent_award': 'Upcoming HC Professional (35 & below)',
            'criteria': [
                {'name': 'Commitment to professional education', 'weight': 15},
                {'name': 'Contribution in the workplace', 'weight': 25},
                {'name': 'Leadership and personal traits (drive, creativity, ambition)', 'weight': 25},
                {'name': 'Volunteerism and community involvement', 'weight': 15},
                {'name': 'Outstanding achievement in 2025', 'weight': 20}
            ]
        },
        'Upcoming HC Professional (35 & below) - Public Sector': {
            'category_type': 'Individual',
            'parent_award': 'Upcoming HC Professional (35 & below)',
            'criteria': [
                {'name': 'Commitment to professional education', 'weight': 15},
                {'name': 'Contribution in the workplace', 'weight': 25},
                {'name': 'Leadership and personal traits (drive, creativity, ambition)', 'weight': 25},
                {'name': 'Volunteerism and community involvement', 'weight': 15},
                {'name': 'Outstanding achievement in 2025', 'weight': 20}
            ]
        },
        'Upcoming HC Professional (35 & below) - NGO': {
            'category_type': 'Individual',
            'parent_award': 'Upcoming HC Professional (35 & below)',
            'criteria': [
                {'name': 'Commitment to professional education', 'weight': 15},
                {'name': 'Contribution in the workplace', 'weight': 25},
                {'name': 'Leadership and personal traits (drive, creativity, ambition)', 'weight': 25},
                {'name': 'Volunteerism and community involvement', 'weight': 15},
                {'name': 'Outstanding achievement in 2025', 'weight': 20}
            ]
        },
        
        # FEMALE HC PRACTITIONER
        'Female HC Practitioner of the Year - Private Sector': {
            'category_type': 'Individual',
            'parent_award': 'Female HC Practitioner of the Year',
            'criteria': [
                {'name': 'Contribution to Profession & IPMZ', 'weight': 20},
                {'name': 'Leadership and Influence', 'weight': 25},
                {'name': 'Organisational Impact and Achievements', 'weight': 25},
                {'name': 'Commitment to Professional & Personal Growth', 'weight': 15},
                {'name': 'Outstanding Achievement in 2025', 'weight': 15}
            ]
        },
        'Female HC Practitioner of the Year - Public Sector': {
            'category_type': 'Individual',
            'parent_award': 'Female HC Practitioner of the Year',
            'criteria': [
                {'name': 'Contribution to Profession & IPMZ', 'weight': 20},
                {'name': 'Leadership and Influence', 'weight': 25},
                {'name': 'Organisational Impact and Achievements', 'weight': 25},
                {'name': 'Commitment to Professional & Personal Growth', 'weight': 15},
                {'name': 'Outstanding Achievement in 2025', 'weight': 15}
            ]
        },
        'Female HC Practitioner of the Year - NGO': {
            'category_type': 'Individual',
            'parent_award': 'Female HC Practitioner of the Year',
            'criteria': [
                {'name': 'Contribution to Profession & IPMZ', 'weight': 20},
                {'name': 'Leadership and Influence', 'weight': 25},
                {'name': 'Organisational Impact and Achievements', 'weight': 25},
                {'name': 'Commitment to Professional & Personal Growth', 'weight': 15},
                {'name': 'Outstanding Achievement in 2025', 'weight': 15}
            ]
        },
        
        # LEADERSHIP COACH
        'Male Leadership Coach of the Year': {
            'category_type': 'Individual',
            'parent_award': 'Leadership Coach of the Year',
            'criteria': [
                {'name': 'Personal brand visibility', 'weight': 15},
                {'name': 'Legacy/track record of nurturing talent', 'weight': 25},
                {'name': 'Contribution to growth of HC Profession', 'weight': 20},
                {'name': 'Passion and mentorship of HR professionals', 'weight': 20},
                {'name': 'Outstanding achievement in 2025', 'weight': 20}
            ]
        },
        'Female Leadership Coach of the Year': {
            'category_type': 'Individual',
            'parent_award': 'Leadership Coach of the Year',
            'criteria': [
                {'name': 'Personal brand visibility', 'weight': 15},
                {'name': 'Legacy/track record of nurturing talent', 'weight': 25},
                {'name': 'Contribution to growth of HC Profession', 'weight': 20},
                {'name': 'Passion and mentorship of HR professionals', 'weight': 20},
                {'name': 'Outstanding achievement in 2025', 'weight': 20}
            ]
        },
        
        # CEO WITH HC ORIENTATION
        'CEO with an HC Orientation - Male': {
            'category_type': 'Individual',
            'parent_award': 'CEO with an HC Orientation',
            'criteria': [
                {'name': 'Commitment to people strategy (incl. diversity & inclusion)', 'weight': 25},
                {'name': 'Support for people development', 'weight': 20},
                {'name': 'Placing HC at the core of business strategy', 'weight': 25},
                {'name': 'Outstanding HC achievement and business impact in 2025', 'weight': 30}
            ]
        },
        'CEO with an HC Orientation - Female': {
            'category_type': 'Individual',
            'parent_award': 'CEO with an HC Orientation',
            'criteria': [
                {'name': 'Commitment to people strategy (incl. diversity & inclusion)', 'weight': 25},
                {'name': 'Support for people development', 'weight': 20},
                {'name': 'Placing HC at the core of business strategy', 'weight': 25},
                {'name': 'Outstanding HC achievement and business impact in 2025', 'weight': 30}
            ]
        },
        
        # CORPORATE AWARDS
        'The Grand Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Comprehensive people strategy', 'weight': 30},
                {'name': 'Outstanding results with far-reaching HC impact', 'weight': 40},
                {'name': 'Passion, dedication, and development of people', 'weight': 30}
            ]
        },
        'Leadership Development Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Innovative leadership programmes/frameworks', 'weight': 25},
                {'name': 'Integrated management & leadership framework', 'weight': 25},
                {'name': 'Alignment between vision and leadership principles', 'weight': 20},
                {'name': 'Programmes producing champions of change', 'weight': 30}
            ]
        },
        'Diversity, Equity, and Inclusion Excellence Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Evidence of impactful diversity strategy', 'weight': 25},
                {'name': 'Inclusiveness in talent strategy', 'weight': 20},
                {'name': 'Implementation embedded into culture', 'weight': 20},
                {'name': 'Contribution to growth and sustainability', 'weight': 20},
                {'name': 'Link to broader business strategy', 'weight': 15}
            ]
        },
        'People Impact Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'People development strategy aligned with business goals', 'weight': 25},
                {'name': 'Embedding learning philosophy into daily work', 'weight': 20},
                {'name': 'Innovative L&D addressing business issues', 'weight': 25},
                {'name': 'Top-level commitment to L&D', 'weight': 15},
                {'name': 'Outstanding achievement in 2024', 'weight': 15}
            ]
        },
        'IPMZ Business Partner Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Demonstrated consistent partnership', 'weight': 25},
                {'name': 'Sponsorship value and consistency', 'weight': 25},
                {'name': 'Training partnerships (employee participation)', 'weight': 25},
                {'name': 'Membership support and engagement', 'weight': 25}
            ]
        },
        'Environmental, Social & Governance Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Positive influence from ESG initiatives', 'weight': 35},
                {'name': 'Sustainability and ethical impact', 'weight': 35},
                {'name': 'Outstanding innovation in 2025', 'weight': 30}
            ]
        },
        'Wellness, Safety & Sustainability Leadership Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Comprehensive holistic strategy', 'weight': 20},
                {'name': 'Impact measurement', 'weight': 15},
                {'name': 'Employee engagement', 'weight': 15},
                {'name': 'Innovation and relevance in 2025', 'weight': 15},
                {'name': 'Sustainability and growth', 'weight': 15},
                {'name': 'Culture and awareness', 'weight': 20}
            ]
        },
        'HC Team Award': {
            'category_type': 'Corporate - Private Sector',
            'criteria': [
                {'name': 'Unity of purpose and tangible results', 'weight': 25},
                {'name': 'Influence through innovative approaches', 'weight': 25},
                {'name': 'Strategic approach to HC management', 'weight': 25},
                {'name': 'Commitment to HC excellence', 'weight': 25}
            ]
        },
        
        # VENDOR AWARDS
        'Premium Recruitment Agency Award': {
            'category_type': 'HC Vendors',
            'criteria': [
                {'name': 'Website for candidates and employers', 'weight': 10},
                {'name': 'Annual placements (employability rate)', 'weight': 25},
                {'name': 'Clientele base size', 'weight': 20},
                {'name': 'Lead time to place candidates', 'weight': 25},
                {'name': 'Competency recruitment courses / tech updates', 'weight': 20}
            ]
        },
        'Best Medical Aid Company Award': {
            'category_type': 'HC Vendors',
            'criteria': [
                {'name': 'Accessibility to major hospitals', 'weight': 20},
                {'name': 'Coverage for all conditions', 'weight': 20},
                {'name': 'Medical insurance covering shortfalls', 'weight': 20},
                {'name': 'Health, nutrition, and wellness programmes', 'weight': 20},
                {'name': 'Outstanding innovation in 2025', 'weight': 20}
            ]
        },
        'Best HC Consulting & Training Firm Award': {
            'category_type': 'HC Vendors',
            'criteria': [
                {'name': 'Measurable outcomes', 'weight': 25},
                {'name': 'Experience and track record', 'weight': 20},
                {'name': 'Relevant HC statistics aligned to trends', 'weight': 20},
                {'name': 'Capability courses for strategic HC roles', 'weight': 20},
                {'name': 'Outstanding innovation in 2025', 'weight': 15}
            ]
        },
        'Best HCIS Firm Award': {
            'category_type': 'HC Vendors',
            'criteria': [
                {'name': 'Advanced features beyond payroll', 'weight': 20},
                {'name': 'User-friendliness and uptime', 'weight': 20},
                {'name': 'Use of automation/biometrics', 'weight': 20},
                {'name': 'Client education on legislation/taxation', 'weight': 20},
                {'name': 'Outstanding innovation in 2025', 'weight': 20}
            ]
        },
        
        # SME SECTOR
        'Best SME Organisational Strategy and HC Innovation Award': {
            'category_type': 'SME Sector',
            'criteria': [
                {'name': 'Strategic alignment of HC with business objectives', 'weight': 25},
                {'name': 'Innovation in HC practices for SME context', 'weight': 25},
                {'name': 'Measurable impact on organisational performance', 'weight': 25},
                {'name': 'Sustainability and scalability of HC initiatives', 'weight': 25}
            ]
        }
    }
    
    # Background check items
    BACKGROUND_CHECKS = [
        'Nominee identity verified',
        'Company sector alignment confirmed',
        'Social media presence reviewed'
    ]


# ===================== PDF EXTRACTION =====================

class PDFExtractor:
    """Extract and parse nomination PDFs"""
    
    def __init__(self, pdf_file):
        self.pdf_file = pdf_file
        self.raw_text = ""
        self.data = {
            'award': '',
            'nominee_name': '',
            'company': '',
            'email': '',
            'phone': '',
            'narrative': '',
            'word_count': 0
        }
        self.is_valid = False
        self.errors = []
        self.warnings = []
    
    def extract(self):
        """Main extraction method"""
        try:
            with pdfplumber.open(self.pdf_file) as pdf:
                self.raw_text = "\n".join([page.extract_text() or "" for page in pdf.pages])
            
            self._parse_fields()
            self._validate()
            
            return True
            
        except Exception as e:
            self.errors.append(f"PDF extraction error: {str(e)}")
            return False
    
    def _parse_fields(self):
        """Parse structured fields from text"""
        
        patterns = {
            'award': r'Award[:\s]+(.+?)(?:\n|Nominee)',
            'nominee_name': r'Nominee\s+Name[:\s]+(.+?)(?:\n)',
            'company': r'Nominee\s+Company[:\s]+(.+?)(?:\n)',
            'email': r'Nominee\s+Email[:\s]+(.+?)(?:\n)',
            'phone': r'Nominee\s+Cell[:\s]+(.+?)(?:\n|$)'
        }
        
        for field, pattern in patterns.items():
            match = re.search(pattern, self.raw_text, re.IGNORECASE | re.MULTILINE)
            if match:
                self.data[field] = match.group(1).strip()
        
        narrative_pattern = r'Best\s+practices.*?(?:words?)[:\s]*(.+?)(?:_{5,}|Supervisor|Manager|$)'
        narrative_match = re.search(narrative_pattern, self.raw_text, re.IGNORECASE | re.DOTALL)
        
        if narrative_match:
            self.data['narrative'] = narrative_match.group(1).strip()
        else:
            lines = self.raw_text.split('\n')
            content_lines = [line.strip() for line in lines if len(line.strip()) > 50]
            self.data['narrative'] = ' '.join(content_lines)
        
        self.data['word_count'] = len(self.data['narrative'].split())
    
    def _validate(self):
        """Validate extracted data"""
        
        self.is_valid = True
        
        if 'lorem ipsum' in self.raw_text.lower():
            self.errors.append("Contains placeholder text (Lorem Ipsum)")
            self.is_valid = False
        
        required = ['award', 'nominee_name', 'company', 'email', 'phone']
        for field in required:
            if not self.data.get(field):
                self.errors.append(f"Missing required field: {field}")
                self.is_valid = False
        
        if self.data['email']:
            if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', self.data['email']):
                self.errors.append(f"Invalid email format: {self.data['email']}")
                self.is_valid = False
        
        word_count = self.data['word_count']
        if word_count < 100:
            self.errors.append(f"Narrative too short: {word_count} words (minimum 500)")
            self.is_valid = False
        elif word_count > 1500:
            self.warnings.append(f"Narrative exceeds limit: {word_count} words (maximum 1500)")
        else:
            self.warnings.append(f"Word count acceptable: {word_count} words")
        
        if not re.search(r'supervisor|manager', self.raw_text, re.IGNORECASE):
            self.warnings.append("No supervisor/manager signature section detected")


# ===================== SCORING ENGINE =====================

class ScoringEngine:
    """Calculate scores based on award-specific rubric"""
    
    def __init__(self):
        self.config = ScoringConfig()
        self.criteria_scores = {}
        self.total_score = 0
        self.disqualified = False
        self.disqualification_reasons = []
        self.background_checks = {}
    
    def calculate_score(self, award_category, criteria_scores):
        """Calculate total score for specific award"""
        
        if award_category not in self.config.AWARD_CATEGORIES:
            return 0
        
        total = sum(criteria_scores.values())
        self.total_score = round(total, 2)
        return self.total_score
    
    def check_disqualifications(self, flags):
        """Check disqualification criteria - REMOVED"""
        self.disqualification_reasons = []
        self.disqualified = False
        return self.disqualified
    
    def get_performance_rating(self, score):
        """Get performance rating based on score"""
        if score >= 90:
            return "Exceptional", "#10b981"
        elif score >= 75:
            return "Excellent", "#3b82f6"
        elif score >= 60:
            return "Good", "#8b5cf6"
        elif score >= 50:
            return "Satisfactory", "#f59e0b"
        else:
            return "Needs Improvement", "#ef4444"


# ===================== PERSISTENT DATA STORAGE WITH AUTO-RANKING =====================

class DataStore:
    """Persistent JSON-based data storage with automatic ranking"""
    
    def __init__(self, filename="nominations_data.json"):
        self.filename = filename
        self.data = self._load()
        st.write(f"DataStore initialized. Current nominations: {len(self.data.get('nominations', []))}")
    
    def _load(self):
        """Load data from JSON file"""
        try:
            file_path = Path(self.filename)
            if file_path.exists():
                with open(self.filename, 'r', encoding='utf-8') as f:
                    loaded_data = json.load(f)
                    st.write(f"✅ Loaded {len(loaded_data.get('nominations', []))} nominations from file")
                    return loaded_data
            else:
                st.write("📝 No existing data file found. Starting fresh.")
        except Exception as e:
            st.error(f"Error loading data: {e}")
        return {'nominations': [], 'last_updated': None}
    
    def _save(self):
        """Save data to JSON file with timestamp"""
        try:
            self.data['last_updated'] = datetime.now().isoformat()
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            st.write(f"💾 Saved {len(self.data['nominations'])} nominations to file")
            return True
        except Exception as e:
            st.error(f"Error saving data: {e}")
            return False
    
    def add_nomination(self, nomination):
        """Add new nomination and auto-update rankings"""
        try:
            # Generate unique ID
            existing_ids = [n.get('id', 0) for n in self.data['nominations']]
            nomination['id'] = max(existing_ids) + 1 if existing_ids else 1
            nomination['timestamp'] = datetime.now().isoformat()
            
            # Add to nominations list
            self.data['nominations'].append(nomination)
            
            st.write(f"➕ Added nomination #{nomination['id']}: {nomination.get('nominee_name', 'Unknown')}")
            
            # Auto-update rankings for this award category
            self._update_category_rankings(nomination['award_category'])
            
            # Save to file
            if self._save():
                st.success(f"✅ Successfully saved nomination #{nomination['id']}")
                return nomination['id']
            else:
                st.error("❌ Failed to save nomination")
                return None
        except Exception as e:
            st.error(f"Error adding nomination: {e}")
            return None
    
    def _update_category_rankings(self, award_category):
        """Update rankings for all nominees in a specific award category"""
        try:
            # Get all scored nominations for this category
            category_nominations = [
                n for n in self.data['nominations'] 
                if n.get('award_category') == award_category and n.get('status') == 'scored'
            ]
            
            st.write(f"🔢 Ranking {len(category_nominations)} nominees in {award_category}")
            
            # Sort by total score (highest first)
            category_nominations.sort(key=lambda x: x.get('total_score', 0), reverse=True)
            
            # Update rank for each nominee
            for rank, nomination in enumerate(category_nominations, 1):
                nomination['category_rank'] = rank
                nomination['total_in_category'] = len(category_nominations)
                st.write(f"  Rank #{rank}: {nomination.get('nominee_name')} - Score: {nomination.get('total_score')}")
        except Exception as e:
            st.error(f"Error updating rankings: {e}")
    
    def update_all_rankings(self):
        """Update rankings for all award categories"""
        try:
            # Get all unique award categories
            categories = set(n.get('award_category') for n in self.data['nominations'] if n.get('status') == 'scored')
            
            st.write(f"🔄 Updating rankings for {len(categories)} categories")
            
            for category in categories:
                self._update_category_rankings(category)
            
            self._save()
            st.success("✅ All rankings updated successfully!")
        except Exception as e:
            st.error(f"Error updating all rankings: {e}")
    
    def get_all_nominations(self):
        """Get all nominations"""
        noms = self.data.get('nominations', [])
        st.write(f"📊 Retrieved {len(noms)} total nominations")
        return noms
    
    def get_nominations_by_category(self, award_category):
        """Get ranked nominations for a specific category"""
        nominations = [
            n for n in self.data['nominations'] 
            if n.get('award_category') == award_category and n.get('status') == 'scored'
        ]
        # Sort by rank
        nominations.sort(key=lambda x: x.get('category_rank', 999))
        return nominations
    
    def get_all_categories_with_rankings(self):
        """Get all award categories with their ranked nominees"""
        scored = [n for n in self.data['nominations'] if n.get('status') == 'scored']
        
        st.write(f"📋 Processing {len(scored)} scored nominations")
        
        # Group by award category
        categories = {}
        for nom in scored:
            category = nom.get('award_category', 'Unknown')
            if category not in categories:
                categories[category] = []
            categories[category].append(nom)
        
        # Sort each category by rank
        for category in categories:
            categories[category].sort(key=lambda x: x.get('category_rank', 999))
        
        st.write(f"📁 Found {len(categories)} unique categories")
        return categories
    
    def generate_comprehensive_report(self):
        """Generate comprehensive report with all data"""
        scored = [n for n in self.data['nominations'] if n.get('status') == 'scored']
        categories_data = self.get_all_categories_with_rankings()
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_nominations': len(scored),
            'total_categories': len(categories_data),
            'categories': {}
        }
        
        for category, nominations in categories_data.items():
            scores = [n.get('total_score', 0) for n in nominations]
            
            report['categories'][category] = {
                'total_nominees': len(nominations),
                'avg_score': float(np.mean(scores)) if scores else 0,
                'highest_score': float(max(scores)) if scores else 0,
                'lowest_score': float(min(scores)) if scores else 0,
                'nominees': []
            }
            
            for nom in nominations:
                report['categories'][category]['nominees'].append({
                    'rank': nom.get('category_rank', 0),
                    'name': nom.get('nominee_name', ''),
                    'company': nom.get('company', ''),
                    'score': float(nom.get('total_score', 0)),
                    'rating': nom.get('rating', ''),
                    'criteria_scores': nom.get('criteria_scores', {}),
                    'criteria_notes': nom.get('criteria_notes', {}),
                    'background_checks': nom.get('background_checks', {}),
                    'timestamp': nom.get('timestamp', '')
                })
        
        return report


# ===================== STREAMLIT APP =====================

def main():
    st.set_page_config(
        page_title="IPMZ Award Scoring System",
        page_icon="🏆",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.markdown("""
        <style>
        .main-header {
            background: linear-gradient(90deg, #059669 0%, #047857 100%);
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            color: white;
        }
        .metric-card {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #059669;
        }
        </style>
    """, unsafe_allow_html=True)
    
    st.markdown("""
        <div class="main-header">
            <h1 style='margin: 0;'>🏆 Human Capital Excellence Awards</h1>
            <p style='margin: 0.5rem 0 0 0; font-size: 1.1rem; color: #d1fae5;'>
                Verification & Scoring System with Auto-Ranking
            </p>
        </div>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'extractor' not in st.session_state:
        st.session_state.extractor = None
    if 'scoring_engine' not in st.session_state:
        st.session_state.scoring_engine = ScoringEngine()
    if 'data_store' not in st.session_state:
        st.session_state.data_store = DataStore()
    
    with st.sidebar:
        st.image("https://via.placeholder.com/200x100/059669/FFFFFF?text=IPMZ", use_container_width=True)
        st.markdown("### Navigation")
        st.markdown("---")
        
        nominations = st.session_state.data_store.get_all_nominations()
        scored_noms = [n for n in nominations if n.get('status') == 'scored']
        
        st.markdown(f"**Total Nominations:** {len(scored_noms)}")
        
        if scored_noms:
            # Update rankings button
            if st.button("🔄 Refresh Rankings", use_container_width=True):
                st.session_state.data_store.update_all_rankings()
                st.rerun()
        
        st.markdown("---")
        st.markdown("### Quick Stats")
        if scored_noms:
            avg_score = np.mean([n.get('total_score', 0) for n in scored_noms])
            st.metric("Average Score", f"{avg_score:.1f}")
            st.metric("Total Reviewed", len(scored_noms))
            
            categories = len(set(n.get('award_category') for n in scored_noms))
            st.metric("Categories", categories)
    
    tabs = st.tabs([
        "📄 Upload & Validate",
        "✅ Background Check",
        "📊 Score Nomination",
        "📈 Results & Analysis",
        "🏆 All Nominations (Ranked)",
        "📚 Scoring Guide"
    ])
    
    with tabs[0]:
        render_upload_tab()
    
    with tabs[1]:
        render_background_check_tab()
    
    with tabs[2]:
        render_scoring_tab()
    
    with tabs[3]:
        render_results_tab()
    
    with tabs[4]:
        render_all_nominations_tab()
    
    with tabs[5]:
        render_guide_tab()


def render_upload_tab():
    """Render upload and validation tab"""
    
    st.header("📄 Upload Nomination Document")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        uploaded_file = st.file_uploader(
            "Upload PDF nomination form",
            type=['pdf'],
            help="Upload the completed IPMZ nomination form"
        )
    
    with col2:
        st.info("""
        **Requirements:**
        - PDF format
        - 500-1500 words
        - All required fields
        - No placeholder text
        """)
    
    if uploaded_file:
        with st.spinner("🔍 Extracting and validating..."):
            extractor = PDFExtractor(uploaded_file)
            
            if extractor.extract():
                st.session_state.extractor = extractor
                
                st.success("✅ PDF processed successfully!")
                
                st.subheader("📋 Extracted Information")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.markdown("**Award Category**")
                    st.info(extractor.data['award'] or "Not found")
                with col2:
                    st.markdown("**Nominee Name**")
                    st.info(extractor.data['nominee_name'] or "Not found")
                with col3:
                    st.markdown("**Company**")
                    st.info(extractor.data['company'] or "Not found")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("**Email**")
                    st.info(extractor.data['email'] or "Not found")
                with col2:
                    st.markdown("**Phone**")
                    st.info(extractor.data['phone'] or "Not found")
                
                st.markdown("**Narrative Excerpt**")
                narrative = extractor.data['narrative']
                preview = ' '.join(narrative.split()[:100])
                if len(narrative.split()) > 100:
                    preview += "..."
                st.text_area("First 100 words", preview, height=150, disabled=True)
                
                st.subheader("✅ Validation Results")
                
                if extractor.is_valid:
                    st.success("✅ **Nomination passes initial validation**")
                else:
                    st.error("❌ **Nomination has critical errors - please review**")
                
                if extractor.errors:
                    st.markdown("**❌ Errors:**")
                    for error in extractor.errors:
                        st.error(error)
                
                if extractor.warnings:
                    st.markdown("**⚠️ Warnings/Notes:**")
                    for warning in extractor.warnings:
                        st.warning(warning)
                
                st.markdown("---")
                if extractor.is_valid:
                    if st.button("➡️ Proceed to Background Check", type="primary"):
                        st.info("Please switch to the 'Background Check' tab to continue")
                else:
                    st.warning("⚠️ Please resolve errors before proceeding")


def render_background_check_tab():
    """Render background check tab"""
    
    st.header("✅ Background Verification")
    
    if not st.session_state.extractor:
        st.warning("⚠️ Please upload and validate a nomination first.")
        return
    
    extractor = st.session_state.extractor
    
    if not extractor.is_valid:
        st.error("❌ Cannot proceed with background check on invalid nomination.")
        return
    
    st.markdown(f"**Nominee:** {extractor.data['nominee_name']}")
    st.markdown(f"**Company:** {extractor.data['company']}")
    st.markdown(f"**Award Category:** {extractor.data['award']}")
    
    st.markdown("---")
    
    st.subheader("🔍 Background Check Items")
    st.markdown("Check each item as verification is completed:")
    
    config = ScoringConfig()
    background_checks = {}
    
    cols = st.columns(2)
    for i, check_item in enumerate(config.BACKGROUND_CHECKS):
        with cols[i % 2]:
            background_checks[check_item] = st.checkbox(
                check_item,
                key=f"bg_{i}",
                help="Check this box once verification is complete"
            )
    
    st.markdown("---")
    
    # Additional notes
    st.subheader("📝 Background Check Notes")
    bg_notes = st.text_area(
        "Additional notes or findings",
        height=150,
        placeholder="Enter any additional information from the background check process..."
    )
    
    # Calculate completion
    total_checks = len(config.BACKGROUND_CHECKS)
    completed_checks = sum(background_checks.values())
    completion_rate = (completed_checks / total_checks) * 100
    
    st.markdown("---")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Checks Completed", f"{completed_checks}/{total_checks}")
    
    with col2:
        st.metric("Completion Rate", f"{completion_rate:.0f}%")
    
    with col3:
        if completion_rate == 100:
            st.success("✅ All checks complete")
        else:
            st.warning(f"⚠️ {total_checks - completed_checks} remaining")
    
    # Progress bar
    st.progress(completion_rate / 100)
    
    st.markdown("---")
    
    # Flag for issues
    has_issues = st.checkbox("🚩 Flag issues found during background check", key="bg_issues")
    
    if has_issues:
        st.warning("⚠️ **ATTENTION:** Issues flagged - please note in the scoring process")
        issue_details = st.text_area(
            "Describe the issues",
            height=100,
            placeholder="Detail the specific issues found..."
        )
    
    # Save background check
    if st.button("💾 Save Background Check Results", type="primary"):
        st.session_state.background_check_completed = True
        st.session_state.background_checks = background_checks
        st.session_state.background_notes = bg_notes
        st.session_state.background_has_issues = has_issues
        
        if has_issues:
            st.session_state.background_issue_details = issue_details if has_issues else ""
        
        st.success("✅ Background check results saved!")
        
        if completion_rate == 100 and not has_issues:
            st.info("➡️ You may now proceed to the 'Score Nomination' tab")
        elif has_issues:
            st.warning("⚠️ Issues flagged - consider these during scoring")
        else:
            st.warning(f"⚠️ Background check is {completion_rate:.0f}% complete - consider completing all checks before scoring")


def render_scoring_tab():
    """Render award-specific scoring tab"""
    
    st.header("📊 Score Nomination")
    
    if not st.session_state.extractor:
        st.warning("⚠️ Please upload and validate a nomination first.")
        return
    
    extractor = st.session_state.extractor
    
    if not extractor.is_valid:
        st.error("❌ Cannot score an invalid nomination.")
        return
    
    # Check background verification
    if not st.session_state.get('background_check_completed', False):
        st.warning("⚠️ Background check not completed. Please complete background verification first.")
        if st.button("Skip to Scoring (Not Recommended)"):
            st.session_state.background_check_skipped = True
        if not st.session_state.get('background_check_skipped', False):
            return
    
    st.markdown(f"**Scoring for:** {extractor.data['nominee_name']} - {extractor.data['company']}")
    st.markdown(f"**Original Award from Document:** {extractor.data['award']}")
    st.markdown("---")
    
    # Background check summary
    if st.session_state.get('background_check_completed', False):
        with st.expander("✅ Background Check Summary"):
            checks = st.session_state.get('background_checks', {})
            completed = sum(checks.values())
            total = len(checks)
            st.metric("Verification Completion", f"{completed}/{total}")
            
            if st.session_state.get('background_has_issues', False):
                st.warning("⚠️ Issues noted during background check")
    
    st.markdown("---")
    
    # USER SELECTS AWARD CATEGORY
    st.subheader("🏆 Select Award Category")
    st.info("⚠️ **Important:** Please select the exact award category from the dropdown below. This ensures proper categorization and ranking.")
    
    config = ScoringConfig()
    all_categories = list(config.AWARD_CATEGORIES.keys())
    
    # Group categories by type for easier selection
    category_by_type = {}
    for cat in all_categories:
        cat_type = config.AWARD_CATEGORIES[cat]['category_type']
        if cat_type not in category_by_type:
            category_by_type[cat_type] = []
        category_by_type[cat_type].append(cat)
    
    # Display organized selection
    st.markdown("**Choose the award category:**")
    
    # Create a flat list with separators for display
    category_options = []
    category_display = []
    
    for cat_type in sorted(category_by_type.keys()):
        category_display.append(f"─── {cat_type} ───")
        category_options.append(None)  # Separator (not selectable)
        for cat in sorted(category_by_type[cat_type]):
            category_display.append(f"  {cat}")
            category_options.append(cat)
    
    # User selects from dropdown
    selected_index = st.selectbox(
        "Award Category",
        range(len(category_display)),
        format_func=lambda x: category_display[x],
        key="award_category_selector"
    )
    
    # Get the actual category (skip separators)
    matched_award = category_options[selected_index]
    
    # If separator selected, show warning
    if matched_award is None:
        st.warning("⚠️ Please select a specific award category, not a category header.")
        return
    
    # Display selected award details
    award_config = config.AWARD_CATEGORIES[matched_award]
    
    st.success(f"✅ Selected: **{matched_award}**")
    
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**Category Type:** {award_config['category_type']}")
    with col2:
        total_points = sum(c['weight'] for c in award_config['criteria'])
        st.markdown(f"**Total Points Available:** {total_points}")
    
    st.markdown("---")
    
    # Score each criterion
    criteria_scores = {}
    criteria_notes = {}
    
    st.markdown("### Score Each Criterion")
    st.markdown("Rate each criterion based on evidence provided:")
    
    for criterion in award_config['criteria']:
        with st.expander(f"**{criterion['name']}** (Weight: {criterion['weight']} points)", expanded=False):
            
            st.markdown(f"Maximum points available: **{criterion['weight']}**")
            
            # Scoring scale guidance
            st.markdown("**Scoring Guidance:**")
            st.markdown(f"- **{criterion['weight']}**: Exceptional - Exceeds all expectations with outstanding evidence")
            st.markdown(f"- **{int(criterion['weight'] * 0.75)}-{criterion['weight']-1}**: Excellent - Strong evidence with measurable impact")
            st.markdown(f"- **{int(criterion['weight'] * 0.5)}-{int(criterion['weight'] * 0.74)}**: Good - Solid evidence meeting expectations")
            st.markdown(f"- **{int(criterion['weight'] * 0.25)}-{int(criterion['weight'] * 0.49)}**: Satisfactory - Basic evidence provided")
            st.markdown(f"- **0-{int(criterion['weight'] * 0.24)}**: Needs improvement - Insufficient evidence")
            
            # Score slider
            score = st.slider(
                f"Points awarded",
                min_value=0,
                max_value=criterion['weight'],
                value=int(criterion['weight'] / 2),
                step=1,
                key=f"crit_{matched_award}_{criterion['name']}"
            )
            
            criteria_scores[criterion['name']] = score
            
            # Justification
            notes = st.text_area(
                "Justification for score",
                key=f"notes_{matched_award}_{criterion['name']}",
                placeholder="Provide specific evidence and reasoning for this score...",
                height=100
            )
            
            criteria_notes[criterion['name']] = notes
    
    st.markdown("---")
    
    # Calculate final score
    if st.button("🎯 Calculate Final Score", type="primary"):
        engine = st.session_state.scoring_engine
        total_score = engine.calculate_score(matched_award, criteria_scores)
        
        st.session_state.final_scores = {
            'award_category': matched_award,
            'original_award_name': extractor.data['award'],
            'criteria_scores': criteria_scores,
            'criteria_notes': criteria_notes,
            'total_score': total_score
        }
        
        st.balloons()
        st.success(f"✅ Scoring Complete!")
        
        # Display result
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Score", f"{total_score:.2f}/100")
        
        with col2:
            rating, color = engine.get_performance_rating(total_score)
            st.markdown(f"**Rating:** <span style='color: {color}; font-weight: bold;'>{rating}</span>", unsafe_allow_html=True)
        
        with col3:
            if st.button("💾 Save & Auto-Rank", key="save_button"):
                nomination_data = {
                    **extractor.data,
                    'status': 'scored',
                    'award_category': matched_award,
                    'original_award_name': extractor.data['award'],
                    'category_type': award_config['category_type'],
                    'criteria_scores': criteria_scores,
                    'criteria_notes': criteria_notes,
                    'total_score': total_score,
                    'rating': rating,
                    'background_checks': st.session_state.get('background_checks', {}),
                    'background_notes': st.session_state.get('background_notes', '')
                }
                
                st.write("🔄 Saving nomination...")
                
                # Save and get ID
                nomination_id = st.session_state.data_store.add_nomination(nomination_data)
                
                if nomination_id:
                    # Get updated ranking
                    ranked_noms = st.session_state.data_store.get_nominations_by_category(matched_award)
                    current_nom = next((n for n in ranked_noms if n['id'] == nomination_id), None)
                    
                    if current_nom:
                        rank = current_nom.get('category_rank', 0)
                        total_in_cat = current_nom.get('total_in_category', 0)
                        st.success(f"🎉 Saved! Ranked #{rank} out of {total_in_cat} in {matched_award}")
                    else:
                        st.success("✅ Saved to database!")
                    
                    # Clear for next nomination
                    st.session_state.background_check_completed = False
                    st.session_state.background_checks = {}
                    st.session_state.extractor = None
                    st.session_state.final_scores = None
                    
                    st.info("✨ Ready for next nomination! Go to 'Upload & Validate' tab or check 'All Nominations' tab to see rankings.")
                    
                    # Add a rerun button to refresh the page
                    if st.button("🔄 Start New Nomination", type="secondary"):
                        st.rerun()
                else:
                    st.error("❌ Failed to save nomination. Please try again.")
        
        # Score breakdown
        st.subheader("📊 Score Breakdown")
        
        breakdown_df = pd.DataFrame([
            {
                'Criterion': crit,
                'Score Awarded': score,
                'Maximum Points': next(c['weight'] for c in award_config['criteria'] if c['name'] == crit),
                'Percentage': f"{(score / next(c['weight'] for c in award_config['criteria'] if c['name'] == crit) * 100):.1f}%"
            }
            for crit, score in criteria_scores.items()
        ])
        
        st.dataframe(breakdown_df, use_container_width=True)


def render_results_tab():
    """Render results and analysis tab"""
    
    st.header("📈 Results & Analysis")
    
    if 'final_scores' not in st.session_state or st.session_state.final_scores is None:
        st.warning("⚠️ No scoring results available. Please complete scoring first.")
        return
    
    scores = st.session_state.final_scores
    extractor = st.session_state.extractor
    
    if not extractor:
        st.warning("⚠️ No nominee data available.")
        return
    
    engine = st.session_state.scoring_engine
    
    # Summary Cards
    st.subheader("📊 Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Nominee", extractor.data['nominee_name'])
    
    with col2:
        st.metric("Company", extractor.data['company'])
    
    with col3:
        st.metric("Total Score", f"{scores['total_score']:.2f}/100")
    
    with col4:
        rating, color = engine.get_performance_rating(scores['total_score'])
        st.markdown(f"**Rating**<br><span style='color: {color}; font-size: 1.5rem; font-weight: bold;'>{rating}</span>", unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Visualizations
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Criteria Performance")
        
        criteria_names = [name[:30] + '...' if len(name) > 30 else name for name in scores['criteria_scores'].keys()]
        criteria_values = list(scores['criteria_scores'].values())
        
        # Get max values for each criterion
        config = ScoringConfig()
        award_config = config.AWARD_CATEGORIES[scores['award_category']]
        max_values = [c['weight'] for c in award_config['criteria']]
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            y=criteria_names,
            x=criteria_values,
            name='Score Awarded',
            orientation='h',
            marker=dict(color='#059669')
        ))
        
        fig.add_trace(go.Bar(
            y=criteria_names,
            x=[m - v for m, v in zip(max_values, criteria_values)],
            name='Points Available',
            orientation='h',
            marker=dict(color='#d1d5db')
        ))
        
        fig.update_layout(
            barmode='stack',
            height=400,
            showlegend=True,
            xaxis_title="Points",
            margin=dict(l=0, r=0, t=20, b=0)
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("🎯 Performance Gauge")
        
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=scores['total_score'],
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Overall Score"},
            delta={'reference': 75, 'increasing': {'color': "#059669"}},
            gauge={
                'axis': {'range': [None, 100]},
                'bar': {'color': "#059669"},
                'steps': [
                    {'range': [0, 50], 'color': "#fee2e2"},
                    {'range': [50, 75], 'color': "#fef3c7"},
                    {'range': [75, 90], 'color': "#dbeafe"},
                    {'range': [90, 100], 'color': "#d1fae5"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 90
                }
            }
        ))
        
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    # Detailed breakdown
    st.subheader("📋 Detailed Criterion Analysis")
    
    for criterion_name, score in scores['criteria_scores'].items():
        max_points = next(c['weight'] for c in award_config['criteria'] if c['name'] == criterion_name)
        percentage = (score / max_points) * 100
        
        with st.expander(f"**{criterion_name}** - {score}/{max_points} ({percentage:.1f}%)"):
            col1, col2 = st.columns([1, 2])
            
            with col1:
                st.metric("Points Awarded", f"{score}/{max_points}")
                st.progress(percentage / 100)
            
            with col2:
                st.markdown("**Justification:**")
                notes = scores['criteria_notes'].get(criterion_name, "No notes provided")
                st.info(notes if notes else "No notes provided")
    
    st.markdown("---")
    
    # Export options
    st.subheader("💾 Export Options")
    
    col1, col2 = st.columns(2)
    
    with col1:
        output = io.BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            # Nominee info
            info_df = pd.DataFrame([{
                **extractor.data,
                'award_category': scores['award_category'],
                'total_score': scores['total_score'],
                'rating': rating
            }])
            info_df.to_excel(writer, sheet_name='Nominee Info', index=False)
            
            # Criteria scores
            criteria_df = pd.DataFrame([
                {
                    'Criterion': crit,
                    'Score': score,
                    'Max Points': next(c['weight'] for c in award_config['criteria'] if c['name'] == crit),
                    'Percentage': f"{(score / next(c['weight'] for c in award_config['criteria'] if c['name'] == crit) * 100):.1f}%",
                    'Notes': scores['criteria_notes'].get(crit, '')
                }
                for crit, score in scores['criteria_scores'].items()
            ])
            criteria_df.to_excel(writer, sheet_name='Criteria Scores', index=False)
        
        excel_data = output.getvalue()
        
        st.download_button(
            label="📥 Download Excel Report",
            data=excel_data,
            file_name=f"award_report_{extractor.data['nominee_name'].replace(' ', '_')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            type="primary"
        )
    
    with col2:
        csv_data = pd.DataFrame([
            {
                'Criterion': crit,
                'Score': score,
                'Max Points': next(c['weight'] for c in award_config['criteria'] if c['name'] == crit)
            }
            for crit, score in scores['criteria_scores'].items()
        ]).to_csv(index=False)
        
        st.download_button(
            label="📥 Download CSV Summary",
            data=csv_data,
            file_name=f"award_summary_{extractor.data['nominee_name'].replace(' ', '_')}.csv",
            mime="text/csv"
        )


def render_all_nominations_tab():
    """Render all nominations with automatic ranking by category"""
    
    st.header("🏆 All Nominations - Auto-Ranked by Category")
    
    # Debug section
    with st.expander("🔍 Debug Info", expanded=False):
        data_store = st.session_state.data_store
        all_noms = data_store.get_all_nominations()
        st.write(f"Total nominations in database: {len(all_noms)}")
        st.write(f"Data file: {data_store.filename}")
        st.write(f"File exists: {Path(data_store.filename).exists()}")
        if all_noms:
            st.write("Sample nomination:")
            st.json(all_noms[0])
    
    data_store = st.session_state.data_store
    categories_with_rankings = data_store.get_all_categories_with_rankings()
    
    if not categories_with_rankings:
        st.info("📭 No nominations stored yet. Score some nominations to see them here!")
        st.write(f"Checked {len(data_store.get_all_nominations())} nominations in database")
        return
    
    # Summary statistics
    all_noms = data_store.get_all_nominations()
    scored_noms = [n for n in all_noms if n.get('status') == 'scored']
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Nominations", len(scored_noms))
    
    with col2:
        st.metric("Award Categories", len(categories_with_rankings))
    
    with col3:
        if scored_noms:
            avg_score = np.mean([n['total_score'] for n in scored_noms])
            st.metric("Average Score", f"{avg_score:.1f}")
        else:
            st.metric("Average Score", "N/A")
    
    with col4:
        last_updated = data_store.data.get('last_updated', 'Never')
        if last_updated != 'Never':
            try:
                last_updated = datetime.fromisoformat(last_updated).strftime("%Y-%m-%d %H:%M")
            except:
                pass
        st.metric("Last Updated", last_updated)
    
    st.markdown("---")
    
    # Display each category with rankings
    for category, nominees in sorted(categories_with_rankings.items()):
        with st.expander(f"📋 **{category}** ({len(nominees)} nominees)", expanded=True):
            
            # Category stats
            scores = [n['total_score'] for n in nominees]
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Nominees", len(nominees))
            with col2:
                st.metric("Avg Score", f"{np.mean(scores):.1f}")
            with col3:
                st.metric("Highest", f"{max(scores):.1f}")
            
            st.markdown("---")
            
            # Rankings table
            ranking_data = []
            for nom in nominees:
                medal = "🥇" if nom.get('category_rank') == 1 else "🥈" if nom.get('category_rank') == 2 else "🥉" if nom.get('category_rank') == 3 else f"#{nom.get('category_rank', 'N/A')}"
                
                ranking_data.append({
                    'Rank': medal,
                    'Nominee': nom.get('nominee_name', 'Unknown'),
                    'Company': nom.get('company', 'Unknown'),
                    'Total Score': f"{nom.get('total_score', 0):.2f}",
                    'Rating': nom.get('rating', ''),
                    'Timestamp': datetime.fromisoformat(nom.get('timestamp', '')).strftime("%Y-%m-%d %H:%M") if nom.get('timestamp') else 'N/A'
                })
            
            ranking_df = pd.DataFrame(ranking_data)
            st.dataframe(ranking_df, use_container_width=True, hide_index=True)
            
            # Top 3 highlights
            if len(nominees) >= 3:
                st.markdown("**🎯 Top 3 Performers:**")
                cols = st.columns(3)
                for idx, nom in enumerate(nominees[:3]):
                    with cols[idx]:
                        medal = "🥇" if idx == 0 else "🥈" if idx == 1 else "🥉"
                        st.markdown(f"**{medal} {nom.get('nominee_name', 'Unknown')}**")
                        st.caption(f"{nom.get('company', 'Unknown')}")
                        st.metric("Score", f"{nom.get('total_score', 0):.2f}")
    
    st.markdown("---")
    
    # DOWNLOAD COMPREHENSIVE REPORT
    st.subheader("📥 Download Comprehensive Report")
    
    st.markdown("""
    Generate a complete Excel report with:
    - All nominees ranked by category
    - Detailed scoring breakdowns
    - Criteria-level analysis
    - Merit justifications for each score
    """)
    
    if st.button("📊 Generate Full Comprehensive Report", type="primary", use_container_width=True):
        with st.spinner("Generating comprehensive report..."):
            report = data_store.generate_comprehensive_report()
            
            # Create Excel file
            output = io.BytesIO()
            
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # SHEET 1: Executive Summary
                summary_data = [{
                    'Report Generated': report['generated_at'],
                    'Total Nominations': report['total_nominations'],
                    'Total Categories': report['total_categories'],
                    'System Average': np.mean([nom['score'] for cat in report['categories'].values() for nom in cat['nominees']]) if report['total_nominations'] > 0 else 0
                }]
                pd.DataFrame(summary_data).to_excel(writer, sheet_name='Executive Summary', index=False)
                
                # SHEET 2: Category Overview
                category_overview = []
                for category, data in report['categories'].items():
                    category_overview.append({
                        'Award Category': category,
                        'Total Nominees': data['total_nominees'],
                        'Average Score': f"{data['avg_score']:.2f}",
                        'Highest Score': f"{data['highest_score']:.2f}",
                        'Lowest Score': f"{data['lowest_score']:.2f}",
                        'Winner': data['nominees'][0]['name'] if data['nominees'] else 'N/A'
                    })
                pd.DataFrame(category_overview).to_excel(writer, sheet_name='Category Overview', index=False)
                
                # SHEET 3: Complete Rankings (All Categories)
                all_rankings = []
                for category, data in report['categories'].items():
                    for nom in data['nominees']:
                        all_rankings.append({
                            'Award Category': category,
                            'Rank': nom['rank'],
                            'Nominee Name': nom['name'],
                            'Company': nom['company'],
                            'Total Score': f"{nom['score']:.2f}",
                            'Rating': nom['rating'],
                            'Background Checks': f"{sum(nom['background_checks'].values())}/{len(nom['background_checks'])}" if nom['background_checks'] else 'N/A',
                            'Timestamp': datetime.fromisoformat(nom['timestamp']).strftime("%Y-%m-%d %H:%M") if nom['timestamp'] else 'N/A'
                        })
                pd.DataFrame(all_rankings).to_excel(writer, sheet_name='Complete Rankings', index=False)
                
                # SHEET 4-N: Individual Category Rankings with Merit Details
                for category, data in report['categories'].items():
                    # Clean sheet name (Excel has 31 char limit)
                    sheet_name = category[:28] + '...' if len(category) > 31 else category
                    
                    category_detail = []
                    for nom in data['nominees']:
                        category_detail.append({
                            'Rank': nom['rank'],
                            'Nominee': nom['name'],
                            'Company': nom['company'],
                            'Total Score': f"{nom['score']:.2f}",
                            'Rating': nom['rating']
                        })
                    pd.DataFrame(category_detail).to_excel(writer, sheet_name=sheet_name, index=False)
                
                # SHEET: Detailed Criteria Scores
                criteria_details = []
                for category, data in report['categories'].items():
                    for nom in data['nominees']:
                        for criterion, score in nom['criteria_scores'].items():
                            criteria_details.append({
                                'Award Category': category,
                                'Rank': nom['rank'],
                                'Nominee': nom['name'],
                                'Company': nom['company'],
                                'Criterion': criterion[:50],  # Truncate long criteria names
                                'Score': score,
                                'Merit Justification': nom['criteria_notes'].get(criterion, '')[:500]  # Truncate long notes
                            })
                
                if criteria_details:
                    pd.DataFrame(criteria_details).to_excel(writer, sheet_name='Criteria & Merit Details', index=False)
                
                # SHEET: Top Performers Across All Categories
                top_performers = []
                for category, data in report['categories'].items():
                    if data['nominees']:
                        winner = data['nominees'][0]
                        top_performers.append({
                            'Award Category': category,
                            'Winner': winner['name'],
                            'Company': winner['company'],
                            'Score': f"{winner['score']:.2f}",
                            'Rating': winner['rating'],
                            'Total Nominees in Category': data['total_nominees']
                        })
                
                if top_performers:
                    pd.DataFrame(top_performers).to_excel(writer, sheet_name='Winners Summary', index=False)
            
            excel_data = output.getvalue()
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            st.download_button(
                label="📥 Download Complete Report with Merit Justifications",
                data=excel_data,
                file_name=f"IPMZ_Awards_Comprehensive_Report_{timestamp}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                type="primary",
                use_container_width=True
            )
            
            st.success("✅ Report generated successfully! Click the button above to download.")
            
            # Show preview of what's in the report
            with st.expander("📋 Report Contents Preview"):
                st.markdown("**The report includes:**")
                st.markdown("1. **Executive Summary** - Overall statistics")
                st.markdown("2. **Category Overview** - All categories with winners")
                st.markdown("3. **Complete Rankings** - All nominees ranked")
                st.markdown(f"4. **Individual Category Sheets** - {len(report['categories'])} detailed sheets")
                st.markdown("5. **Criteria & Merit Details** - Complete scoring justifications")
                st.markdown("6. **Winners Summary** - Top performers across all categories")


def render_guide_tab():
    """Render scoring guide"""
    
    st.header("📚 Scoring Guide & Award Categories")
    
    st.markdown("""
    ### 🎯 Scoring Philosophy
    
    This system uses award-specific criteria aligned with IPMZ standards:
    
    - **Award-Specific Scoring**: Each award has unique criteria with specific weights
    - **Evidence-Based Assessment**: Scores based on documented achievements
    - **Background Verification**: Comprehensive checks before scoring
    - **Automatic Ranking**: Rankings update automatically when nominations are saved
    - **Persistent Storage**: All data saved permanently and automatically organized by category
    """)
    
    st.markdown("---")
    
    # Award categories
    config = ScoringConfig()
    
    st.subheader("🏆 Award Categories")
    
    # Group by category type
    category_types = {}
    for award, details in config.AWARD_CATEGORIES.items():
        cat_type = details['category_type']
        if cat_type not in category_types:
            category_types[cat_type] = []
        category_types[cat_type].append((award, details))
    
    for cat_type, awards in category_types.items():
        st.markdown(f"### 📂 {cat_type} Awards")
        
        for award_name, award_config in awards:
            with st.expander(f"**{award_name}**"):
                st.markdown("**Scoring Criteria:**")
                
                criteria_df = pd.DataFrame([
                    {
                        'Criterion': c['name'],
                        'Weight (Points)': c['weight']
                    }
                    for c in award_config['criteria']
                ])
                
                st.dataframe(criteria_df, use_container_width=True)
                
                total_weight = sum(c['weight'] for c in award_config['criteria'])
                st.markdown(f"**Total Points Available:** {total_weight}")
        
        st.markdown("---")
    
    # Performance ratings
    st.subheader("🏅 Performance Ratings")
    
    ratings_df = pd.DataFrame([
        {'Rating': 'Exceptional', 'Score Range': '90-100', 'Description': 'Industry-leading performance'},
        {'Rating': 'Excellent', 'Score Range': '75-89', 'Description': 'Above industry standards'},
        {'Rating': 'Good', 'Score Range': '60-74', 'Description': 'Meets standards'},
        {'Rating': 'Satisfactory', 'Score Range': '50-59', 'Description': 'Minimum requirements'},
        {'Rating': 'Needs Improvement', 'Score Range': 'Below 50', 'Description': 'Below expected standards'}
    ])
    
    st.dataframe(ratings_df, use_container_width=True)
    
    st.markdown("---")
    
    # Background checks
    st.subheader("✅ Background Verification Requirements")
    
    st.markdown("All nominees must undergo the following checks:")
    for i, check in enumerate(config.BACKGROUND_CHECKS, 1):
        st.markdown(f"{i}. {check}")
    
    st.markdown("---")
    
    # How rankings work
    st.subheader("🏆 How Automatic Rankings Work")
    
    st.markdown("""
    ### Automatic Ranking System:
    
    1. **Real-time Updates**: Rankings are calculated automatically when you save a nomination
    2. **Category-Specific**: Each award category has its own separate ranking
    3. **Score-Based**: Nominees are ranked by total score (highest to lowest)
    4. **Persistent Storage**: All data is saved to `nominations_data.json` file
    5. **No Data Loss**: System persists data between sessions - no need to reload
    
    ### What Gets Saved:
    - ✅ Nominee information and contact details
    - ✅ Complete scoring breakdown by criteria
    - ✅ Merit justifications for each score
    - ✅ Background check results
    - ✅ Automatic category ranking
    - ✅ Timestamp of scoring
    
    ### Comprehensive Report Features:
    - 📊 Executive summary with overall statistics
    - 🏆 Category-by-category rankings
    - 📋 Complete merit justifications
    - 📈 Detailed criteria-level analysis
    - 🎯 Winners summary across all categories
    """)


if __name__ == "__main__":
    main()